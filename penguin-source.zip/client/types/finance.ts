export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  categoryId: string;
  subCategory?: string; // optional sub-category, e.g. '地铁', '停车费'
  amount: number;
  date: string; // YYYY-MM-DD
  note: string;
  imageBase64?: string; // data URL for local storage
  createdAt: string; // ISO string
}

export interface Category {
  id: string;
  name: string;
  type: 'income' | 'expense';
  icon: string; // Feather icon name
  isCustom: boolean;
  subCategories?: string[]; // optional preset sub-categories
}

export const DEFAULT_CATEGORIES: Category[] = [
  // Expense
  { id: 'exp_food', name: '餐饮', type: 'expense', icon: 'coffee', isCustom: false, subCategories: ['早餐', '午餐', '晚餐', '外卖', '零食', '咖啡'] },
  { id: 'exp_transport', name: '交通', type: 'expense', icon: 'navigation', isCustom: false, subCategories: ['地铁', '公交', '打车', '停车费', '加油', '高铁/飞机'] },
  { id: 'exp_shopping', name: '购物', type: 'expense', icon: 'shopping-bag', isCustom: false, subCategories: ['日用品', '服装', '数码', '美妆', '零食'] },
  { id: 'exp_fun', name: '娱乐', type: 'expense', icon: 'music', isCustom: false, subCategories: ['电影', '游戏', '旅行', '健身', '聚会'] },
  { id: 'exp_home', name: '居住', type: 'expense', icon: 'home', isCustom: false, subCategories: ['房租', '水电煤', '物业', '日用品'] },
  { id: 'exp_medical', name: '医疗', type: 'expense', icon: 'heart', isCustom: false, subCategories: ['药品', '门诊', '体检', '保险'] },
  { id: 'exp_edu', name: '教育', type: 'expense', icon: 'book-open', isCustom: false, subCategories: ['学费', '图书', '课程', '文具'] },
  { id: 'exp_comm', name: '通讯', type: 'expense', icon: 'smartphone', isCustom: false, subCategories: ['话费', '流量', '宽带'] },
  { id: 'exp_other', name: '其他', type: 'expense', icon: 'more-horizontal', isCustom: false },
  // Income
  { id: 'inc_salary', name: '工资', type: 'income', icon: 'briefcase', isCustom: false, subCategories: ['基本工资', '奖金', '补贴', '年终奖'] },
  { id: 'inc_parttime', name: '兼职', type: 'income', icon: 'clock', isCustom: false, subCategories: ['劳务', '接单'] },
  { id: 'inc_invest', name: '理财', type: 'income', icon: 'trending-up', isCustom: false, subCategories: ['利息', '基金', '股票'] },
  { id: 'inc_other', name: '其他', type: 'income', icon: 'more-horizontal', isCustom: false },
];

export const STORAGE_KEYS = {
  TRANSACTIONS: '@finance_transactions',
  CATEGORIES: '@finance_categories',
};
