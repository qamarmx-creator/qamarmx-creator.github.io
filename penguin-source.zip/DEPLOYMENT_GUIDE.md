# 企鹅记账 PWA — 部署与维护指南

本文档供以后人工修改「网页版软件」使用。

## 一、应用是什么

- 技术栈：Expo 54 + React Native（前端）、Express.js（后端，当前 PWA 未启用后端）
- 部署形态：PWA（渐进式 Web 应用），托管在 GitHub Pages
- 线上网址：`https://qamarmx-creator.github.io`
- 所有数据保存在**手机本地**（浏览器 localStorage），不走云端，记账需手动备份

## 二、项目目录结构

```
/workspace/projects/
├── client/                      # 前端（Expo/RN）
│   ├── app/                     # Expo Router 路由（仅 re-export）
│   │   ├── _layout.tsx          # 根布局
│   │   └── (tabs)/…             # Tab：index(记账)/history(明细)/stats(统计)
│   ├── screens/                 # 页面实现
│   │   ├── home/                # 记账首页
│   │   ├── history/             # 明细/历史页
│   │   └── stats/               # 统计页
│   ├── contexts/FinanceContext.tsx   # 核心数据层（记账增删改查 + 本地存储 + 备份恢复）
│   ├── components/
│   │   ├── Screen.tsx           # 页面容器
│   │   ├── PenguinCelebration.tsx  # 企鹅图标映射（分类图标、彩蛋）
│   │   └── ColorSchemeUpdater.tsx  # 主题模式（DEFAULT_THEME）
│   ├── assets/penguins/         # 企鹅图标 penguin_01~19.png（已压缩）
│   ├── types/finance.ts         # 数据模型 + DEFAULT_CATEGORIES（含子分类）
│   ├── app.config.ts            # 应用配置（web 输出、PWA）
│   ├── global.css               # Tailwind 主题 tokens
│   ├── web/                     # PWA 文件（manifest.json、sw.js、index.html）
│   └── package.json
├── server/                      # Express 后端（PWA 当前未使用，可忽略）
├── package.json                 # monorepo 根
└── DEPLOYMENT_GUIDE.md          # 本文档
```

## 三、需要装的环境

- Node.js（>= 20）
- pnpm（包管理器，`npm i -g pnpm`）

## 四、本地开发

```bash
cd /workspace/projects
pnpm install          # 首次安装依赖
coze dev              # 启动前后端本地服务（前端 5000，后端 9091）
```

## 五、常见修改点

| 想改什么 | 改哪里 |
|---------|--------|
| 记账的分类/子分类 | `client/types/finance.ts` 里的 `DEFAULT_CATEGORIES` |
| 分类企鹅图标映射 | `client/components/PenguinCelebration.tsx` 的 `CATEGORY_PENGUIN_MAP` |
| 主题（暗/亮/跟随） | `client/components/ColorSchemeUpdater.tsx` 的 `DEFAULT_THEME` |
| 主题配色 | `client/global.css` |
| 记账逻辑/本地存储/备份 | `client/contexts/FinanceContext.tsx` |
| 记账 / 明细 / 统计页面 UI | `client/screens/home`、`history`、`stats` |
| 页面新增/删除 | `client/app/` + `client/screens/`（见 AGENTS.md 路由规范） |

## 六、构建 PWA 并上线（关键）

改完代码后，把构建产物推送到 GitHub Pages 的仓库根目录：

```bash
cd client
npx expo export --platform web      # 生成静态文件到 dist/
cp web/manifest.json dist/
cp web/sw.js dist/
# 因为 GitHub Pages 会忽略 _expo 目录（下划线开头），把资源挪到 static/ 并改写路径：
mkdir -p dist/static/js/web dist/static/css
cp _expo/static/js/web/*.js dist/static/js/web/
cp _expo/static/css/*.css dist/static/css/
find dist -name "*.html" -exec sed -i 's|/_expo/static/|/static/|g' {} \;
sed -i 's|/_expo/static/|/static/|g' dist/manifest.json dist/sw.js
```

推送（把 `dist/` 内容作为仓库根提交到 `main`，用户名仓库 GitHub Pages 自动部署）：

```bash
cd dist
rm -rf .git
git init
git config user.email "qamarmx-creator@users.noreply.github.com"
git config user.name "qamarmx-creator"
git add -f .
git commit -m "deploy: 更新"
git remote add origin https://qamarmx-creator:<你的GITHUB_TOKEN>@github.com/qamarmx-creator/qamarmx-creator.github.io.git
git branch -M main
git push -f origin main
```

> 关键坑：token 需勾选 `repo` + `workflow` 权限；部署后 GitHub 约 1~2 分钟生效。

## 七、数据存储与备份

- 数据存**手机本地**，网址相同但在 Safari 与「主屏幕快捷方式」是两套隔离存储（iPhone 系统限制）。
- 数据可通过记账页右上角「备份」按钮导出/导入迁移。
- 建议定期用「备份」复制文本存档。

## 八、账号与资源

- GitHub 用户名：`qamarmx-creator`
- 部署仓库：`qamarmx-creator/qamarmx-creator.github.io`
- 素材：企鹅图标源文件在 `/workspace/projects/assets/`；已压缩到 `/workspace/projects/client/assets/penguins/`